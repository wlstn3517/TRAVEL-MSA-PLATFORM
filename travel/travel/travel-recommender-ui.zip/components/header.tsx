import Link from "next/link";
import { Compass } from "lucide-react";

export function Header() {
  return (
    <header className="border-b border-border bg-card">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Compass className="h-6 w-6 text-foreground" />
            <span className="text-xl font-bold text-foreground">
              Travel Recommender
            </span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link
              href="/"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              추천받기
            </Link>
            <Link
              href="/search"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              여행지 검색
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
