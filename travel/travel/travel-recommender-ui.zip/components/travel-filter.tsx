"use client";

import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface TravelFilterProps {
  onSubmit: (filters: FilterState) => void;
}

export interface FilterState {
  region: string;
  duration: string;
  budget: string;
  styles: string[];
}

const travelStyles = [
  { id: "rest", label: "휴식" },
  { id: "food", label: "미식" },
  { id: "activity", label: "액티비티" },
  { id: "sightseeing", label: "관광" },
];

export function TravelFilter({ onSubmit }: TravelFilterProps) {
  const [region, setRegion] = useState<string>("");
  const [duration, setDuration] = useState<string>("");
  const [budget, setBudget] = useState<string>("");
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);

  const handleStyleChange = (styleId: string, checked: boolean) => {
    if (checked) {
      setSelectedStyles((prev) => [...prev, styleId]);
    } else {
      setSelectedStyles((prev) => prev.filter((id) => id !== styleId));
    }
  };

  const handleSubmit = () => {
    onSubmit({
      region,
      duration,
      budget,
      styles: selectedStyles,
    });
  };

  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <h2 className="mb-6 text-lg font-semibold text-card-foreground">
        여행 조건 설정
      </h2>

      <div className="space-y-5">
        {/* 지역 선택 */}
        <div className="space-y-2">
          <Label htmlFor="region" className="text-sm font-medium text-foreground">
            지역
          </Label>
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger id="region" className="w-full">
              <SelectValue placeholder="지역 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="domestic">국내</SelectItem>
              <SelectItem value="overseas">해외</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 여행 기간 */}
        <div className="space-y-2">
          <Label htmlFor="duration" className="text-sm font-medium text-foreground">
            여행 기간
          </Label>
          <Select value={duration} onValueChange={setDuration}>
            <SelectTrigger id="duration" className="w-full">
              <SelectValue placeholder="기간 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1-2">1~2일</SelectItem>
              <SelectItem value="3-4">3~4일</SelectItem>
              <SelectItem value="5+">5일 이상</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 예산 */}
        <div className="space-y-2">
          <Label htmlFor="budget" className="text-sm font-medium text-foreground">
            예산
          </Label>
          <Select value={budget} onValueChange={setBudget}>
            <SelectTrigger id="budget" className="w-full">
              <SelectValue placeholder="예산 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30">30만원 이하</SelectItem>
              <SelectItem value="50">50만원 이하</SelectItem>
              <SelectItem value="100">100만원 이하</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 여행 성향 */}
        <div className="space-y-3">
          <Label className="text-sm font-medium text-foreground">여행 성향</Label>
          <div className="grid grid-cols-2 gap-3">
            {travelStyles.map((style) => (
              <div key={style.id} className="flex items-center space-x-2">
                <Checkbox
                  id={style.id}
                  checked={selectedStyles.includes(style.id)}
                  onCheckedChange={(checked) =>
                    handleStyleChange(style.id, checked as boolean)
                  }
                />
                <Label
                  htmlFor={style.id}
                  className="text-sm font-normal text-muted-foreground cursor-pointer"
                >
                  {style.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* 추천받기 버튼 */}
        <Button onClick={handleSubmit} className="w-full mt-6">
          추천받기
        </Button>
      </div>
    </div>
  );
}
