import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin } from "lucide-react";

interface DestinationCardProps {
  id: string;
  name: string;
  region: string;
  description: string;
  imageUrl: string;
}

export function DestinationCard({
  id,
  name,
  region,
  description,
  imageUrl,
}: DestinationCardProps) {
  return (
    <Link href={`/destination/${id}`}>
      <Card className="overflow-hidden transition-all hover:shadow-lg cursor-pointer group">
        <div className="aspect-[16/10] relative overflow-hidden bg-muted">
          <img
            src={imageUrl || "/placeholder.svg"}
            alt={name}
            className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-105"
            crossOrigin="anonymous"
          />
        </div>
        <CardContent className="p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-sm mb-1">
            <MapPin className="h-3.5 w-3.5" />
            <span>{region}</span>
          </div>
          <h3 className="font-semibold text-lg text-card-foreground mb-2">
            {name}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}
