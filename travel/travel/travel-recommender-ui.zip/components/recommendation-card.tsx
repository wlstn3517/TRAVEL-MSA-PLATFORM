import { Card, CardContent } from "@/components/ui/card";
import { MapPin } from "lucide-react";

interface RecommendationCardProps {
  name: string;
  description: string;
  budget: string;
  imageUrl: string;
  tags: string[];
}

export function RecommendationCard({
  name,
  description,
  budget,
  imageUrl,
  tags,
}: RecommendationCardProps) {
  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-md">
      <div className="aspect-[4/3] relative overflow-hidden bg-muted">
        <img
          src={imageUrl || "/placeholder.svg"}
          alt={name}
          className="object-cover w-full h-full"
          crossOrigin="anonymous"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-1">
              <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <h3 className="font-semibold text-card-foreground truncate">{name}</h3>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {description}
            </p>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-secondary text-secondary-foreground"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
        <div className="pt-3 border-t border-border">
          <p className="text-sm">
            <span className="text-muted-foreground">예상 예산</span>
            <span className="ml-2 font-semibold text-foreground">{budget}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
