"use client";

import { RecommendationCard } from "./recommendation-card";

// 더미 데이터
const dummyRecommendations = [
  {
    id: 1,
    name: "제주도",
    description: "아름다운 자연과 맛있는 음식이 가득한 국내 최고의 휴양지",
    budget: "약 40만원",
    imageUrl: "https://images.unsplash.com/photo-1596026075190-c1e1a3a5cdf1?w=800&auto=format&fit=crop&q=60",
    tags: ["휴식", "미식", "관광"],
  },
  {
    id: 2,
    name: "강릉",
    description: "동해의 푸른 바다와 커피거리가 유명한 감성 여행지",
    budget: "약 25만원",
    imageUrl: "https://images.unsplash.com/photo-1587838036803-5c0a1a847a12?w=800&auto=format&fit=crop&q=60",
    tags: ["휴식", "미식"],
  },
  {
    id: 3,
    name: "부산",
    description: "해운대와 광안리, 다양한 먹거리가 있는 항구도시",
    budget: "약 35만원",
    imageUrl: "https://images.unsplash.com/photo-1538485399081-7191377e8241?w=800&auto=format&fit=crop&q=60",
    tags: ["관광", "미식", "액티비티"],
  },
  {
    id: 4,
    name: "경주",
    description: "천년 고도의 역사와 문화가 살아 숨쉬는 곳",
    budget: "약 30만원",
    imageUrl: "https://images.unsplash.com/photo-1614867966107-9aed64f7cefe?w=800&auto=format&fit=crop&q=60",
    tags: ["관광", "휴식"],
  },
];

interface RecommendationListProps {
  hasSearched: boolean;
}

export function RecommendationList({ hasSearched }: RecommendationListProps) {
  if (!hasSearched) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
          <svg
            className="w-8 h-8 text-muted-foreground"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">
          여행지를 찾아보세요
        </h3>
        <p className="text-muted-foreground text-sm max-w-sm">
          왼쪽에서 원하는 조건을 선택하고 추천받기 버튼을 눌러주세요
        </p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-foreground">추천 여행지</h2>
        <span className="text-sm text-muted-foreground">
          {dummyRecommendations.length}개의 결과
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {dummyRecommendations.map((item) => (
          <RecommendationCard
            key={item.id}
            name={item.name}
            description={item.description}
            budget={item.budget}
            imageUrl={item.imageUrl}
            tags={item.tags}
          />
        ))}
      </div>
    </div>
  );
}
