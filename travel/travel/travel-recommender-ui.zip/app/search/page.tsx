"use client";

import { useState, useMemo } from "react";
import { Header } from "@/components/header";
import { DestinationCard } from "@/components/destination-card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search } from "lucide-react";

const DESTINATIONS = [
  {
    id: 1,
    name: "제주도",
    region: "제주",
    description: "아름다운 해변과 한라산, 올레길이 있는 대한민국 대표 휴양지",
    imageUrl:
      "https://images.unsplash.com/photo-1596503987991-2b1e7eb91228?w=600&h=400&fit=crop",
  },
  {
    id: 2,
    name: "경포대",
    region: "강원",
    description: "동해의 푸른 바다와 소나무 숲이 어우러진 명승지",
    imageUrl:
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&h=400&fit=crop",
  },
  {
    id: 3,
    name: "해운대",
    region: "부산",
    description: "대한민국 최고의 해수욕장과 화려한 도시 야경",
    imageUrl:
      "https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=600&h=400&fit=crop",
  },
  {
    id: 4,
    name: "불국사",
    region: "경상",
    description: "유네스코 세계문화유산으로 지정된 신라 불교 예술의 정수",
    imageUrl:
      "https://images.unsplash.com/photo-1548115184-bc6544d06a58?w=600&h=400&fit=crop",
  },
  {
    id: 5,
    name: "전주 한옥마을",
    region: "전라",
    description: "700여 채의 한옥과 전통 문화가 살아있는 도심 속 마을",
    imageUrl:
      "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=600&h=400&fit=crop",
  },
  {
    id: 6,
    name: "설악산",
    region: "강원",
    description: "웅장한 암봉과 계곡, 사계절 아름다운 국립공원",
    imageUrl:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&h=400&fit=crop",
  },
  {
    id: 7,
    name: "남산타워",
    region: "서울",
    description: "서울의 랜드마크, 아름다운 야경을 감상할 수 있는 명소",
    imageUrl:
      "https://images.unsplash.com/photo-1534604973900-c43ab4c2e0ab?w=600&h=400&fit=crop",
  },
  {
    id: 8,
    name: "광안리",
    region: "부산",
    description: "광안대교의 야경과 함께하는 낭만적인 해변",
    imageUrl:
      "https://images.unsplash.com/photo-1499002238440-d264edd596ec?w=600&h=400&fit=crop",
  },
];

const REGIONS = [
  { value: "all", label: "전체 지역" },
  { value: "서울", label: "서울" },
  { value: "강원", label: "강원" },
  { value: "부산", label: "부산" },
  { value: "제주", label: "제주" },
  { value: "경상", label: "경상" },
  { value: "전라", label: "전라" },
];

export default function SearchPage() {
  const [selectedRegion, setSelectedRegion] = useState("all");

  const filteredDestinations = useMemo(() => {
    if (selectedRegion === "all") {
      return DESTINATIONS;
    }
    return DESTINATIONS.filter((dest) => dest.region === selectedRegion);
  }, [selectedRegion]);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            여행지 검색
          </h1>
          <p className="text-muted-foreground">
            원하는 지역을 선택하여 여행지를 찾아보세요
          </p>
        </div>

        <div className="flex items-center gap-3 mb-8 p-4 bg-card rounded-lg border border-border">
          <Search className="h-5 w-5 text-muted-foreground" />
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="지역 선택" />
            </SelectTrigger>
            <SelectContent>
              {REGIONS.map((region) => (
                <SelectItem key={region.value} value={region.value}>
                  {region.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <span className="text-sm text-muted-foreground ml-auto">
            {filteredDestinations.length}개의 여행지
          </span>
        </div>

        {filteredDestinations.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredDestinations.map((destination) => (
              <DestinationCard
                key={destination.id}
                id={destination.id === 1 ? "jeju" : `dest-${destination.id}`}
                name={destination.name}
                region={destination.region}
                description={destination.description}
                imageUrl={destination.imageUrl}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground">
              선택한 지역에 여행지가 없습니다
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
