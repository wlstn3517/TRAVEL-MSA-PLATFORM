"use client";

import { useState } from "react";
import Link from "next/link";
import { Header } from "@/components/header";
import { ImageGallery } from "@/components/image-gallery";
import { TravelInfo } from "@/components/travel-info";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Ticket, Check } from "lucide-react";

const destinationData = {
  jeju: {
    id: "jeju",
    name: "제주도",
    region: "제주특별자치도",
    description:
      "대한민국 최대의 섬으로, 유네스코 세계자연유산에 등재된 아름다운 자연경관을 자랑합니다. 한라산, 성산일출봉, 만장굴 등 독특한 화산 지형과 에메랄드빛 바다가 어우러져 사계절 내내 관광객들의 발길이 끊이지 않는 명소입니다.",
    detailDescription:
      "제주도는 화산 활동으로 형성된 독특한 지형과 온화한 기후로 한국을 대표하는 관광지입니다. 해안가를 따라 펼쳐진 올레길은 트레킹 명소로 유명하며, 곳곳에 위치한 오름들은 가벼운 등산을 즐기기에 안성맞춤입니다. 흑돼지, 갈치조림, 전복죽 등 제주만의 특색 있는 음식도 여행의 큰 즐거움입니다.",
    tags: ["자연", "휴양", "미식", "액티비티"],
    images: [
      {
        url: "https://images.unsplash.com/photo-1579169825353-fde23e5fbb9e?w=1200&h=800&fit=crop",
        alt: "제주도 해안",
      },
      {
        url: "https://images.unsplash.com/photo-1596786232430-d29b6af27e23?w=600&h=400&fit=crop",
        alt: "한라산",
      },
      {
        url: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=600&h=400&fit=crop",
        alt: "제주 바다",
      },
      {
        url: "https://images.unsplash.com/photo-1544377193-33dcf4d68fb5?w=600&h=400&fit=crop",
        alt: "제주 풍경",
      },
    ],
    travelInfo: {
      bestSeason: "4월 ~ 6월, 9월 ~ 11월",
      recommendedDays: "2박 3일 ~ 4박 5일",
      averageBudget: "50만원 ~ 100만원",
      transportation: "항공 / 페리",
    },
  },
};

export default function DestinationDetailPage() {
  const [couponRequested, setCouponRequested] = useState(false);
  const destination = destinationData.jeju;

  const handleCouponRequest = () => {
    setCouponRequested(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link
          href="/search"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          검색 결과로 돌아가기
        </Link>

        <div className="grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <ImageGallery images={destination.images} />
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div>
              <p className="text-sm text-muted-foreground mb-1">
                {destination.region}
              </p>
              <h1 className="text-3xl font-bold text-foreground mb-3">
                {destination.name}
              </h1>
              <div className="flex flex-wrap gap-2">
                {destination.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            <p className="text-muted-foreground leading-relaxed">
              {destination.description}
            </p>

            <div className="p-5 bg-muted rounded-lg space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-foreground">
                    여행 할인 쿠폰
                  </p>
                  <p className="text-sm text-muted-foreground">
                    숙박 및 액티비티 최대 20% 할인
                  </p>
                </div>
                <Ticket className="h-8 w-8 text-muted-foreground" />
              </div>
              <Button
                onClick={handleCouponRequest}
                disabled={couponRequested}
                className="w-full"
              >
                {couponRequested ? (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    쿠폰 발급 완료
                  </>
                ) : (
                  "쿠폰 요청하기"
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-12 space-y-8">
          <section>
            <h2 className="text-xl font-semibold text-foreground mb-4">
              여행 정보
            </h2>
            <TravelInfo {...destination.travelInfo} />
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-4">
              상세 설명
            </h2>
            <div className="p-6 bg-card border border-border rounded-lg">
              <p className="text-muted-foreground leading-relaxed">
                {destination.detailDescription}
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-4">
              추천 명소
            </h2>
            <div className="grid sm:grid-cols-3 gap-4">
              {["성산일출봉", "한라산 국립공원", "우도"].map((spot) => (
                <div
                  key={spot}
                  className="p-4 bg-card border border-border rounded-lg text-center"
                >
                  <p className="font-medium text-foreground">{spot}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
