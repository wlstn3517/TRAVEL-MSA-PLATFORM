"use client";

import { useState } from "react";
import { Header } from "@/components/header";
import { TravelFilter, type FilterState } from "@/components/travel-filter";
import { RecommendationList } from "@/components/recommendation-list";

export default function Home() {
  const [hasSearched, setHasSearched] = useState(false);

  const handleFilterSubmit = (filters: FilterState) => {
    console.log("[v0] Filter submitted:", filters);
    setHasSearched(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 히어로 섹션 */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-foreground mb-3 text-balance">
            나에게 맞는 여행지를 찾아보세요
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-pretty">
            여행 조건을 선택하면 딱 맞는 여행지를 추천해 드립니다
          </p>
        </div>

        {/* 메인 콘텐츠 */}
        <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-8">
          {/* 필터 영역 */}
          <aside>
            <TravelFilter onSubmit={handleFilterSubmit} />
          </aside>

          {/* 추천 결과 영역 */}
          <section>
            <RecommendationList hasSearched={hasSearched} />
          </section>
        </div>
      </main>
    </div>
  );
}
